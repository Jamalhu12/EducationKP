import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

let supabase

if (!supabaseUrl || !supabaseAnonKey || supabaseUrl === 'your-supabase-url' || supabaseAnonKey === 'your-supabase-anon-key') {
  console.error('Supabase configuration missing. Please click "Connect to Supabase" in the top right corner to set up your project.')
  
  // Create a dummy client to prevent the app from crashing
  supabase = createClient('https://placeholder.supabase.co', 'placeholder-key', {
    auth: {
      persistSession: false
    }
  })
} else {
  supabase = createClient(supabaseUrl, supabaseAnonKey)
}

export { supabase }