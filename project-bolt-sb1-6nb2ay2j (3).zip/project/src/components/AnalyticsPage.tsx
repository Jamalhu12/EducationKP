import React, { useState, useEffect } from 'react'
import { BarChart3, Users, Receipt, TrendingUp, DollarSign } from 'lucide-react'
import { supabase } from '../lib/supabase'

interface AnalyticsData {
  totalStudents: number
  totalInvoices: number
  paidInvoices: number
  unpaidInvoices: number
  totalRevenue: number
  collectionPercentage: number
}

export function AnalyticsPage() {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalStudents: 0,
    totalInvoices: 0,
    paidInvoices: 0,
    unpaidInvoices: 0,
    totalRevenue: 0,
    collectionPercentage: 0
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      setError(null)

      // Fetch total students
      const { count: studentsCount, error: studentsError } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true })

      if (studentsError) throw studentsError

      // Fetch invoice analytics
      const { data: invoices, error: invoicesError } = await supabase
        .from('invoices')
        .select('status, amount')

      if (invoicesError) throw invoicesError

      const totalInvoices = invoices?.length || 0
      const paidInvoices = invoices?.filter(inv => inv.status === 'paid').length || 0
      const unpaidInvoices = invoices?.filter(inv => inv.status === 'unpaid').length || 0
      const totalRevenue = invoices?.filter(inv => inv.status === 'paid')
        .reduce((sum, inv) => sum + inv.amount, 0) || 0
      const collectionPercentage = totalInvoices > 0 ? (paidInvoices / totalInvoices) * 100 : 0

      setAnalytics({
        totalStudents: studentsCount || 0,
        totalInvoices,
        paidInvoices,
        unpaidInvoices,
        totalRevenue,
        collectionPercentage
      })
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalytics()
  }, [])

  const formatCurrency = (amount: number) => {
    return `PKR ${amount.toLocaleString()}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
          <p className="text-gray-600">Loading analytics...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
          <BarChart3 className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-600">Overview of your school's performance</p>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Total Students */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Students</p>
              <p className="text-3xl font-bold text-gray-900">{analytics.totalStudents}</p>
            </div>
            <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Total Invoices */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Invoices</p>
              <p className="text-3xl font-bold text-gray-900">{analytics.totalInvoices}</p>
            </div>
            <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full">
              <Receipt className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        {/* Total Revenue */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(analytics.totalRevenue)}</p>
            </div>
            <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-full">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        {/* Collection Percentage */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Collection Rate</p>
              <p className="text-3xl font-bold text-gray-900">{analytics.collectionPercentage.toFixed(1)}%</p>
            </div>
            <div className="inline-flex items-center justify-center w-12 h-12 bg-orange-100 rounded-full">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>

        {/* Paid vs Unpaid */}
        <div className="bg-white rounded-2xl shadow-xl p-6 md:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-gray-700">Paid Invoices</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-900">{analytics.paidInvoices}</span>
                <span className="text-sm text-gray-500 ml-2">
                  ({analytics.totalInvoices > 0 ? ((analytics.paidInvoices / analytics.totalInvoices) * 100).toFixed(1) : 0}%)
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                <span className="text-gray-700">Unpaid Invoices</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-900">{analytics.unpaidInvoices}</span>
                <span className="text-sm text-gray-500 ml-2">
                  ({analytics.totalInvoices > 0 ? ((analytics.unpaidInvoices / analytics.totalInvoices) * 100).toFixed(1) : 0}%)
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-gray-400 rounded-full"></div>
                <span className="text-gray-700 font-medium">Total</span>
              </div>
              <span className="text-2xl font-bold text-gray-900">{analytics.totalInvoices}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Refresh Button */}
      <div className="text-center">
        <button
          onClick={fetchAnalytics}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
        >
          <BarChart3 className="w-4 h-4" />
          <span>Refresh Analytics</span>
        </button>
      </div>
    </div>
  )
}