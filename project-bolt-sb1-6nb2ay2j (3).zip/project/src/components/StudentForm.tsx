import React, { useState, useEffect } from 'react'
import { X, Save, User } from 'lucide-react'
import { Student } from '../hooks/useStudents'
import { useParents } from '../hooks/useParents'
import { useStudentParents } from '../hooks/useStudentParents'

interface StudentFormProps {
  student?: Student | null
  onSubmit: (student: Omit<Student, 'id'>) => Promise<{ success: boolean; error?: string }>
  onClose: () => void
  loading?: boolean
}

export function StudentForm({ student, onSubmit, onClose, loading = false }: StudentFormProps) {
  const { parents, addParent } = useParents()
  const { linkStudentToParent } = useStudentParents()
  const [formData, setFormData] = useState({
    name: '',
    class: '',
    roll: '',
    fatherName: ''
  })
  const [error, setError] = useState('')

  useEffect(() => {
    if (student) {
      setFormData({
        name: student.name || '',
        class: student.class || '',
        roll: student.roll || '',
        fatherName: student.parents?.[0]?.name || ''
      })
    }
  }, [student])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!formData.name.trim() || !formData.class.trim() || !formData.roll.trim() || !formData.fatherName.trim()) {
      setError('Please fill in all required fields')
      return
    }

    // Create student first
    const studentData = {
      name: formData.name,
      class: formData.class,
      roll: formData.roll
    }
    
    const result = await onSubmit(studentData)
    if (result.success) {
      // Handle father linking
      if (formData.fatherName.trim() && result.data) {
        try {
          // Check if parent with this name already exists
          const existingParent = parents.find(p => 
            p.name?.toLowerCase().trim() === formData.fatherName.toLowerCase().trim()
          )
          
          let parentId = existingParent?.id
          
          // If parent doesn't exist, create new one
          if (!existingParent) {
            const parentResult = await addParent({
              name: formData.fatherName.trim(),
              phone: '' // Empty phone for now
            })
            
            if (parentResult.success && parentResult.data) {
              parentId = parentResult.data.id
            }
          }
          
          // Link student to parent
          if (parentId) {
            await linkStudentToParent(result.data.id, parentId)
          }
        } catch (err) {
          console.error('Error linking parent:', err)
        }
      }
      onClose()
    } else {
      setError(result.error || 'An error occurred')
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {student ? 'Edit Student' : 'Add New Student'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Student Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter student name"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="class" className="block text-sm font-medium text-gray-700 mb-2">
                Class
              </label>
              <input
                id="class"
                name="class"
                type="text"
                value={formData.class}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter class (e.g., 10A, Grade 5)"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="roll" className="block text-sm font-medium text-gray-700 mb-2">
                Roll Number
              </label>
              <input
                id="roll"
                name="roll"
                type="text"
                value={formData.roll}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter roll number"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="fatherName" className="block text-sm font-medium text-gray-700 mb-2">
                Father Name
              </label>
              <input
                id="fatherName"
                name="fatherName"
                type="text"
                value={formData.fatherName}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter father's name"
                disabled={loading}
              />
            </div>
          </div>

          <div className="flex space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 inline-flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg font-medium transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Saving...' : 'Save Student'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}