import React from 'react'
import { User, LogOut, Shield, Users, UserPlus, Receipt, CreditCard, BarChart3 } from 'lucide-react'
import { User as SupabaseUser } from '@supabase/supabase-js'
import { StudentsPage } from './StudentsPage'
import { ParentsPage } from './ParentsPage'
import { InvoicesPage } from './InvoicesPage'
import { ParentPaymentPage } from './ParentPaymentPage'
import { AnalyticsPage } from './AnalyticsPage'

interface DashboardProps {
  user: SupabaseUser
  onSignOut: () => void
  currentPage: string
  onNavigate: (page: string) => void
}

export function Dashboard({ user, onSignOut, currentPage, onNavigate }: DashboardProps) {
  const handleSignOut = async () => {
    await onSignOut()
  }

  const renderContent = () => {
    switch (currentPage) {
      case 'students':
        return <StudentsPage />
      case 'parents':
        return <ParentsPage />
      case 'invoices':
        return <InvoicesPage />
      case 'payment':
        return <ParentPaymentPage />
      case 'analytics':
        return <AnalyticsPage />
      default:
        return (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
                <User className="w-10 h-10 text-green-600" />
              </div>
              
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Welcome!
              </h2>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
                <p className="text-lg text-blue-800">
                  <span className="font-medium">Email:</span> {user.email}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-50 rounded-xl p-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-4">
                    <Shield className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Secure</h3>
                  <p className="text-sm text-gray-600">Your session is protected with Supabase authentication</p>
                </div>

                <div className="bg-gray-50 rounded-xl p-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-full mb-4">
                    <User className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Authenticated</h3>
                  <p className="text-sm text-gray-600">You're successfully logged in to your account</p>
                </div>

                <div className="bg-gray-50 rounded-xl p-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mb-4">
                    <LogOut className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Session Persists</h3>
                  <p className="text-sm text-gray-600">Your login will be remembered across browser refreshes</p>
                </div>
              </div>
            </div>
          </div>
        )
    }
  }
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex items-center space-x-3 mr-8">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="text-xl font-semibold text-gray-900 hover:text-blue-600 transition-colors"
                >
                  Dashboard
                </button>
              </div>
              
              {/* Navigation */}
              <nav className="hidden sm:flex space-x-6">
                <button
                  onClick={() => onNavigate('students')}
                  className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPage === 'students'
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Students</span>
                </button>
                <button
                  onClick={() => onNavigate('parents')}
                  className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPage === 'parents'
                      ? 'bg-green-100 text-green-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Parents</span>
                </button>
                <button
                  onClick={() => onNavigate('invoices')}
                  className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPage === 'invoices'
                      ? 'bg-purple-100 text-purple-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Receipt className="w-4 h-4" />
                  <span>Invoices</span>
                </button>
                <button
                  onClick={() => onNavigate('payment')}
                  className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPage === 'payment'
                      ? 'bg-orange-100 text-orange-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Payment</span>
                </button>
                <button
                  onClick={() => onNavigate('analytics')}
                  className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPage === 'analytics'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Analytics</span>
                </button>
              </nav>
            </div>
            
            <button
              onClick={handleSignOut}
              className="inline-flex items-center space-x-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="sm:hidden bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex space-x-4 py-3">
            <button
              onClick={() => onNavigate('students')}
              className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentPage === 'students'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Students</span>
            </button>
            <button
              onClick={() => onNavigate('parents')}
              className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentPage === 'parents'
                  ? 'bg-green-100 text-green-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>Parents</span>
            </button>
            <button
              onClick={() => onNavigate('invoices')}
              className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentPage === 'invoices'
                  ? 'bg-purple-100 text-purple-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Receipt className="w-4 h-4" />
              <span>Invoices</span>
            </button>
            <button
              onClick={() => onNavigate('payment')}
              className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentPage === 'payment'
                  ? 'bg-orange-100 text-orange-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>Payment</span>
            </button>
            <button
              onClick={() => onNavigate('analytics')}
              className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentPage === 'analytics'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Analytics</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  )
}