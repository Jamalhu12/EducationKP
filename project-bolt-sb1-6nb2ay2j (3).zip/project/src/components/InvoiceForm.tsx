import React, { useState, useEffect } from 'react'
import { X, Save, Receipt, ChevronDown } from 'lucide-react'
import { Invoice } from '../hooks/useInvoices'
import { useStudents } from '../hooks/useStudents'

interface InvoiceFormProps {
  invoice?: Invoice | null
  onSubmit: (invoice: Omit<Invoice, 'id' | 'student' | 'created_at'>) => Promise<{ success: boolean; error?: string }>
  onClose: () => void
  loading?: boolean
}

export function InvoiceForm({ invoice, onSubmit, onClose, loading = false }: InvoiceFormProps) {
  const { students } = useStudents()
  const [formData, setFormData] = useState({
    student_id: '',
    amount: '',
    due_date: '',
    status: 'unpaid' as 'draft' | 'paid' | 'unpaid',
    parent_name: '',
    parent_contact: ''
  })
  const [error, setError] = useState('')
  const [showDropdown, setShowDropdown] = useState(false)

  useEffect(() => {
    if (invoice) {
      setFormData({
        student_id: invoice.student_id || '',
        amount: invoice.amount?.toString() || '',
        due_date: invoice.due_date || '',
        status: invoice.status || 'unpaid',
        parent_name: invoice.parent_name || '',
        parent_contact: invoice.parent_contact || ''
      })
    }
  }, [invoice])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!formData.student_id || !formData.amount || !formData.due_date || !formData.parent_name || !formData.parent_contact) {
      setError('Please fill in all required fields')
      return
    }

    const amount = parseFloat(formData.amount)
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid amount')
      return
    }

    const submitData = {
      student_id: formData.student_id,
      amount: amount,
      due_date: formData.due_date,
      status: formData.status,
      parent_name: formData.parent_name,
      parent_contact: formData.parent_contact
    }

    const result = await onSubmit(submitData)
    if (result.success) {
      onClose()
    } else {
      setError(result.error || 'An error occurred')
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleStudentSelect = (studentId: string) => {
    setFormData(prev => ({
      ...prev,
      student_id: studentId
    }))
    setShowDropdown(false)
  }

  const selectedStudent = students.find(s => s.id === formData.student_id)

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="inline-flex items-center justify-center w-10 h-10 bg-purple-100 rounded-full">
              <Receipt className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {invoice ? 'Edit Invoice' : 'Create New Invoice'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Student *
              </label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors text-left flex items-center justify-between"
                  disabled={loading}
                >
                  <span className={selectedStudent ? 'text-gray-900' : 'text-gray-500'}>
                    {selectedStudent ? `${selectedStudent.name} (${selectedStudent.class})` : 'Select a student'}
                  </span>
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                </button>

                {showDropdown && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto">
                    {students.map((student) => (
                      <button
                        key={student.id}
                        type="button"
                        onClick={() => handleStudentSelect(student.id)}
                        className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                      >
                        <div className="font-medium text-gray-900">{student.name}</div>
                        <div className="text-sm text-gray-500">Class: {student.class} | Roll: {student.roll}</div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                Amount *
              </label>
              <input
                id="amount"
                name="amount"
                type="number"
                step="0.01"
                min="0"
                value={formData.amount}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                placeholder="Enter amount"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="due_date" className="block text-sm font-medium text-gray-700 mb-2">
                Due Date *
              </label>
              <input
                id="due_date"
                name="due_date"
                type="date"
                value={formData.due_date}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="parent_name" className="block text-sm font-medium text-gray-700 mb-2">
                Father Name *
              </label>
              <input
                id="parent_name"
                name="parent_name"
                type="text"
                value={formData.parent_name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                placeholder="Enter father's name"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="parent_contact" className="block text-sm font-medium text-gray-700 mb-2">
                Father Contact *
              </label>
              <input
                id="parent_contact"
                name="parent_contact"
                type="tel"
                value={formData.parent_contact}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                placeholder="Enter father's contact number"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                disabled={loading}
              >
                <option value="draft">Draft</option>
                <option value="unpaid">Unpaid</option>
                <option value="paid">Paid</option>
              </select>
            </div>
          </div>

          <div className="flex space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 inline-flex items-center justify-center space-x-2 px-4 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-lg font-medium transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Saving...' : 'Save Invoice'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}