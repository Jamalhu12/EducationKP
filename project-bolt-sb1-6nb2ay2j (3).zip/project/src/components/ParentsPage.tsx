import React, { useState } from 'react'
import { Plus, Edit, Trash2, UserPlus, Search, Phone } from 'lucide-react'
import { useParents, Parent } from '../hooks/useParents'
import { ParentForm } from './ParentForm'

export function ParentsPage() {
  const { parents, loading, error, addParent, updateParent, deleteParent } = useParents()
  const [showForm, setShowForm] = useState(false)
  const [editingParent, setEditingParent] = useState<Parent | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  const filteredParents = parents.filter(parent =>
    parent.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parent.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parent.students?.some(student => 
      student.name?.toLowerCase().includes(searchTerm.toLowerCase())
    )
  )

  const handleAddParent = async (parentData: Omit<Parent, 'id' | 'students'>) => {
    return await addParent(parentData)
  }

  const handleEditParent = async (parentData: Omit<Parent, 'id' | 'students'>) => {
    if (!editingParent) return { success: false, error: 'No parent selected' }
    return await updateParent(editingParent.id, parentData)
  }

  const handleDeleteParent = async (id: string) => {
    const result = await deleteParent(id)
    if (result.success) {
      setDeleteConfirm(null)
    }
    return result
  }

  const openEditForm = (parent: Parent) => {
    setEditingParent(parent)
    setShowForm(true)
  }

  const closeForm = () => {
    setShowForm(false)
    setEditingParent(null)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mb-4"></div>
          <p className="text-gray-600">Loading parents...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="inline-flex items-center justify-center w-10 h-10 bg-green-100 rounded-full">
            <UserPlus className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Parents</h1>
            <p className="text-gray-600">Manage parent information</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Parent</span>
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search parents by name, phone, or student name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
        />
      </div>

      {/* Parents Table */}
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        {filteredParents.length === 0 ? (
          <div className="text-center py-12">
            <UserPlus className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? 'No parents found' : 'No parents yet'}
            </h3>
            <p className="text-gray-600 mb-4">
              {searchTerm 
                ? 'Try adjusting your search terms' 
                : 'Get started by adding your first parent'
              }
            </p>
            {!searchTerm && (
              <button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add First Parent</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-900">Parent Name</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-900">Phone</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-900">Students</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredParents.map((parent) => (
                  <tr key={parent.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{parent.name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span>{parent.phone}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {parent.students && parent.students.length > 0 ? (
                        <div className="space-y-1">
                          {parent.students.map((student, index) => (
                            <div key={student.id}>
                              <div className="font-medium text-gray-900">{student.name}</div>
                              <div className="text-sm text-gray-500">
                                Class: {student.class} | Roll: {student.roll}
                              </div>
                              {index < parent.students!.length - 1 && <hr className="my-1" />}
                          </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400 italic">No students assigned</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => openEditForm(parent)}
                          className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Edit parent"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(parent.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete parent"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Parent Form Modal */}
      {showForm && (
        <ParentForm
          parent={editingParent}
          onSubmit={editingParent ? handleEditParent : handleAddParent}
          onClose={closeForm}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-red-100 rounded-full mb-4">
                <Trash2 className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Delete Parent</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to delete this parent? This action cannot be undone.
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={() => setDeleteConfirm(null)}
                  className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDeleteParent(deleteConfirm)}
                  className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}