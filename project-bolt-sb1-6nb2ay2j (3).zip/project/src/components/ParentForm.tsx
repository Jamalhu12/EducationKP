import React, { useState, useEffect } from 'react'
import { X, Save, UserPlus, ChevronDown, Plus, Minus } from 'lucide-react'
import { Parent } from '../hooks/useParents'
import { useStudents } from '../hooks/useStudents'
import { useStudentParents } from '../hooks/useStudentParents'

interface ParentFormProps {
  parent?: Parent | null
  onSubmit: (parent: Omit<Parent, 'id' | 'students'>) => Promise<{ success: boolean; error?: string }>
  onClose: () => void
  loading?: boolean
}

export function ParentForm({ parent, onSubmit, onClose, loading = false }: ParentFormProps) {
  const { students } = useStudents()
  const { linkStudentToParent, unlinkStudentFromParent } = useStudentParents()
  const [formData, setFormData] = useState({
    name: '',
    phone: ''
  })
  const [selectedStudents, setSelectedStudents] = useState<string[]>([])
  const [error, setError] = useState('')
  const [showDropdown, setShowDropdown] = useState(false)

  useEffect(() => {
    if (parent) {
      setFormData({
        name: parent.name || '',
        phone: parent.phone || ''
      })
      setSelectedStudents(parent.students?.map(s => s.id) || [])
    }
  }, [parent])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!formData.name.trim() || !formData.phone.trim()) {
      setError('Please fill in all required fields')
      return
    }

    const result = await onSubmit({
      name: formData.name,
      phone: formData.phone
    })

    if (result.success) {
      // Handle student relationships
      if (parent) {
        // For editing, we need to update relationships
        const currentStudents = parent.students?.map(s => s.id) || []
        const studentsToAdd = selectedStudents.filter(id => !currentStudents.includes(id))
        const studentsToRemove = currentStudents.filter(id => !selectedStudents.includes(id))
        
        // Add new relationships
        for (const studentId of studentsToAdd) {
          await linkStudentToParent(studentId, parent.id)
        }
        
        // Remove old relationships
        for (const studentId of studentsToRemove) {
          await unlinkStudentFromParent(studentId, parent.id)
        }
      } else if (result.data) {
        // For new parent, add all selected relationships
        for (const studentId of selectedStudents) {
          await linkStudentToParent(studentId, result.data.id)
        }
      }
      onClose()
    } else {
      setError(result.error || 'An error occurred')
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleStudentToggle = (studentId: string) => {
    setSelectedStudents(prev => 
      prev.includes(studentId) 
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    )
    setShowDropdown(false)
  }

  const removeStudent = (studentId: string) => {
    setSelectedStudents(prev => prev.filter(id => id !== studentId))
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="inline-flex items-center justify-center w-10 h-10 bg-green-100 rounded-full">
              <UserPlus className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {parent ? 'Edit Parent' : 'Add New Parent'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Parent Name *
              </label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                placeholder="Enter parent name"
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number *
              </label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                placeholder="Enter phone number"
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Students (Optional)
              </label>
              
              {/* Selected Students */}
              {selectedStudents.length > 0 && (
                <div className="mb-3 space-y-2">
                  {selectedStudents.map(studentId => {
                    const student = students.find(s => s.id === studentId)
                    return student ? (
                      <div key={studentId} className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                        <div>
                          <span className="font-medium text-green-900">{student.name}</span>
                          <span className="text-sm text-green-600 ml-2">({student.class})</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeStudent(studentId)}
                          className="text-green-600 hover:text-green-800 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                      </div>
                    ) : null
                  })}
                </div>
              )}
              
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors text-left flex items-center justify-between"
                  disabled={loading}
                >
                  <span className="text-gray-500">
                    Add students to this parent
                  </span>
                  <Plus className="w-5 h-5 text-gray-400" />
                </button>

                {showDropdown && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto">
                    {students.filter(student => !selectedStudents.includes(student.id)).map((student) => (
                      <button
                        key={student.id}
                        type="button"
                        onClick={() => handleStudentToggle(student.id)}
                        className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                      >
                        <div className="font-medium text-gray-900">{student.name}</div>
                        <div className="text-sm text-gray-500">Class: {student.class} | Roll: {student.roll}</div>
                      </button>
                    ))}
                    {students.filter(student => !selectedStudents.includes(student.id)).length === 0 && (
                      <div className="px-4 py-3 text-gray-500 text-center">
                        All students are already selected
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 inline-flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white rounded-lg font-medium transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Saving...' : 'Save Parent'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}