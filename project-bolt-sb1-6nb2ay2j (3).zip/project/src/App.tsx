import React, { useState } from 'react'
import { useAuth } from './hooks/useAuth'
import { AuthForm } from './components/AuthForm'
import { Dashboard } from './components/Dashboard'

function App() {
  const { user, loading, signUp, signIn, signOut } = useAuth()
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentPage, setCurrentPage] = useState('dashboard')

  const handleAuth = async (email: string, password: string) => {
    setIsSubmitting(true)
    try {
      if (authMode === 'signup') {
        const result = await signUp(email, password)
        return result
      } else {
        const result = await signIn(email, password)
        return result
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSignOut = async () => {
    await signOut()
    setCurrentPage('dashboard')
  }

  const toggleAuthMode = () => {
    setAuthMode(authMode === 'signin' ? 'signup' : 'signin')
  }

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  // Show dashboard if user is authenticated
  if (user) {
    return (
      <Dashboard 
        user={user} 
        onSignOut={handleSignOut}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />
    )
  }

  // Show auth form if user is not authenticated
  return (
    <AuthForm
      mode={authMode}
      onSubmit={handleAuth}
      onModeChange={toggleAuthMode}
      loading={isSubmitting}
    />
  )
}

export default App