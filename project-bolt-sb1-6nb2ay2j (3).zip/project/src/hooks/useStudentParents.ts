import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export interface StudentParent {
  id: string
  student_id: string
  parent_id: string
  created_at: string
}

export function useStudentParents() {
  const [relationships, setRelationships] = useState<StudentParent[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchRelationships = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data, error } = await supabase
        .from('student_parents')
        .select('*')

      if (error) throw error
      setRelationships(data || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const linkStudentToParent = async (studentId: string, parentId: string) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('student_parents')
        .insert([{ student_id: studentId, parent_id: parentId }])
        .select()
        .single()

      if (error) throw error
      
      setRelationships(prev => [...prev, data])
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const unlinkStudentFromParent = async (studentId: string, parentId: string) => {
    try {
      setError(null)
      
      const { error } = await supabase
        .from('student_parents')
        .delete()
        .eq('student_id', studentId)
        .eq('parent_id', parentId)

      if (error) throw error
      
      setRelationships(prev => prev.filter(rel => 
        !(rel.student_id === studentId && rel.parent_id === parentId)
      ))
      return { success: true }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const getParentsForStudent = (studentId: string) => {
    return relationships.filter(rel => rel.student_id === studentId)
  }

  const getStudentsForParent = (parentId: string) => {
    return relationships.filter(rel => rel.parent_id === parentId)
  }

  useEffect(() => {
    fetchRelationships()
  }, [])

  return {
    relationships,
    loading,
    error,
    linkStudentToParent,
    unlinkStudentFromParent,
    getParentsForStudent,
    getStudentsForParent,
    refetch: fetchRelationships
  }
}