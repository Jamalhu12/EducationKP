import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useStudentParents } from './useStudentParents'

export interface Parent {
  id: string
  name: string
  phone: string
  students?: {
    id: string
    name: string
    class: string
    roll: string
  }
}

export function useParents() {
  const [parents, setParents] = useState<Parent[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { relationships } = useStudentParents()

  const fetchParents = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data, error } = await supabase
        .from('parents')
        .select('*')
        .order('name')

      if (error) throw error
      
      // Get students for each parent through relationships
      const parentsWithStudents = await Promise.all(
        (data || []).map(async (parent) => {
          const studentRelations = relationships.filter(rel => rel.parent_id === parent.id)
          
          if (studentRelations.length > 0) {
            const { data: students, error: studentsError } = await supabase
              .from('students')
              .select('id, name, class, roll')
              .in('id', studentRelations.map(rel => rel.student_id))
            
            if (!studentsError) {
              return { ...parent, students: students || [] }
            }
          }
          
          return { ...parent, students: [] }
        })
      )
      
      setParents(parentsWithStudents)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const addParent = async (parent: Omit<Parent, 'id' | 'students'>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('parents')
        .insert([parent])
        .select('*')
        .single()

      if (error) throw error
      
      setParents(prev => [...prev, { ...data, students: [] }])
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const updateParent = async (id: string, updates: Partial<Omit<Parent, 'id' | 'students'>>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('parents')
        .update(updates)
        .eq('id', id)
        .select('*')
        .single()

      if (error) throw error
      
      setParents(prev => prev.map(parent => 
        parent.id === id ? { ...data, students: parent.students } : parent
      ))
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const deleteParent = async (id: string) => {
    try {
      setError(null)
      
      const { error } = await supabase
        .from('parents')
        .delete()
        .eq('id', id)

      if (error) throw error
      
      setParents(prev => prev.filter(parent => parent.id !== id))
      return { success: true }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  useEffect(() => {
    fetchParents()
  }, [])

  return {
    parents,
    loading,
    error,
    addParent,
    updateParent,
    deleteParent,
    refetch: fetchParents
  }
}