import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useStudentParents } from './useStudentParents'

export interface Student {
  id: string
  name: string
  class: string
  roll: string
  parents?: {
    id: string
    name: string
    phone: string
  }[]
}

export function useStudents() {
  const [students, setStudents] = useState<Student[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { relationships } = useStudentParents()

  const fetchStudents = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('name')

      if (error) throw error
      
      // Get parents for each student through relationships
      const studentsWithParents = await Promise.all(
        (data || []).map(async (student) => {
          const parentRelations = relationships.filter(rel => rel.student_id === student.id)
          
          if (parentRelations.length > 0) {
            const { data: parents, error: parentsError } = await supabase
              .from('parents')
              .select('id, name, phone')
              .in('id', parentRelations.map(rel => rel.parent_id))
            
            if (!parentsError) {
              return { ...student, parents: parents || [] }
            }
          }
          
          return { ...student, parents: [] }
        })
      )
      
      setStudents(studentsWithParents)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const addStudent = async (student: Omit<Student, 'id' | 'parents'>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('students')
        .insert([student])
        .select()
        .single()

      if (error) throw error
      
      setStudents(prev => [...prev, { ...data, parents: [] }])
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const updateStudent = async (id: string, updates: Partial<Omit<Student, 'id' | 'parents'>>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('students')
        .update(updates)
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      
      setStudents(prev => prev.map(student => 
        student.id === id ? { ...data, parents: student.parents } : student
      ))
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const deleteStudent = async (id: string) => {
    try {
      setError(null)
      
      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id)

      if (error) throw error
      
      setStudents(prev => prev.filter(student => student.id !== id))
      return { success: true }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  useEffect(() => {
    fetchStudents()
  }, [])

  return {
    students,
    loading,
    error,
    addStudent,
    updateStudent,
    deleteStudent,
    refetch: fetchStudents
  }
}