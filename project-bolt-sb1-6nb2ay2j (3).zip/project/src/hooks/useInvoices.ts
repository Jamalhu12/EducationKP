import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export interface Invoice {
  id: string
  student_id: string
  amount: number
  due_date: string
  status: 'draft' | 'paid' | 'unpaid'
  created_at?: string
  payment_date?: string
  parent_name?: string
  parent_contact?: string
  student?: {
    id: string
    name: string
    class: string
    roll: string
  }
}

export function useInvoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchInvoices = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data, error } = await supabase
        .from('invoices')
        .select(`
          *,
          student:students(id, name, class, roll)
        `)
        .order('due_date', { ascending: false })

      if (error) throw error
      setInvoices(data || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const addInvoice = async (invoice: Omit<Invoice, 'id' | 'student' | 'created_at'>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('invoices')
        .insert([invoice])
        .select(`
          *,
          student:students(id, name, class, roll)
        `)
        .single()

      if (error) throw error
      
      setInvoices(prev => [data, ...prev])
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const updateInvoice = async (id: string, updates: Partial<Omit<Invoice, 'id' | 'student' | 'created_at'>>) => {
    try {
      setError(null)
      
      const { data, error } = await supabase
        .from('invoices')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          student:students(id, name, class, roll)
        `)
        .single()

      if (error) throw error
      
      setInvoices(prev => prev.map(invoice => 
        invoice.id === id ? data : invoice
      ))
      return { success: true, data }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  const markAsPaid = async (id: string) => {
    return await updateInvoice(id, { 
      status: 'paid',
      payment_date: new Date().toISOString()
    })
  }

  const deleteInvoice = async (id: string) => {
    try {
      setError(null)
      
      const { error } = await supabase
        .from('invoices')
        .delete()
        .eq('id', id)

      if (error) throw error
      
      setInvoices(prev => prev.filter(invoice => invoice.id !== id))
      return { success: true }
    } catch (err: any) {
      setError(err.message)
      return { success: false, error: err.message }
    }
  }

  useEffect(() => {
    fetchInvoices()
  }, [])

  return {
    invoices,
    loading,
    error,
    addInvoice,
    updateInvoice,
    markAsPaid,
    deleteInvoice,
    refetch: fetchInvoices
  }
}