import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Calculate date 3 days from now
    const threeDaysFromNow = new Date()
    threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3)
    const dueDateThreshold = threeDaysFromNow.toISOString().split('T')[0]

    // Fetch unpaid invoices due within 3 days
    const { data: invoices, error: invoicesError } = await supabaseClient
      .from('invoices')
      .select(`
        id,
        amount,
        due_date,
        student:students(
          id,
          name,
          student_parents(
            parent:parents(
              id,
              name,
              phone
            )
          )
        )
      `)
      .eq('status', 'unpaid')
      .lte('due_date', dueDateThreshold)

    if (invoicesError) {
      throw new Error(`Failed to fetch invoices: ${invoicesError.message}`)
    }

    let remindersSent = 0
    const results = []

    // Process each invoice
    for (const invoice of invoices || []) {
      if (!invoice.student || !invoice.student.student_parents) continue

      // Send reminder to each parent of the student
      for (const studentParent of invoice.student.student_parents) {
        const parent = studentParent.parent
        if (!parent || !parent.phone) continue

        try {
          // Format the reminder message
          const message = `Assalamualaikum ${parent.name}, ${invoice.student.name} ki fees PKR ${invoice.amount} due hai (Due Date: ${new Date(invoice.due_date).toLocaleDateString('en-GB')}). Kirpya fees jama karen. Online pay link: https://your-payment-link.com/pay/${invoice.id}`

          // Here you would integrate with your SMS/WhatsApp service
          // For demo purposes, we'll simulate the API call
          const smsResult = await sendSMS(parent.phone, message)
          
          if (smsResult.success) {
            remindersSent++
            results.push({
              parentName: parent.name,
              studentName: invoice.student.name,
              phone: parent.phone,
              amount: invoice.amount,
              status: 'sent'
            })
          } else {
            results.push({
              parentName: parent.name,
              studentName: invoice.student.name,
              phone: parent.phone,
              amount: invoice.amount,
              status: 'failed',
              error: smsResult.error
            })
          }
        } catch (error) {
          results.push({
            parentName: parent.name,
            studentName: invoice.student.name,
            phone: parent.phone,
            amount: invoice.amount,
            status: 'failed',
            error: error.message
          })
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        remindersSent,
        totalInvoices: invoices?.length || 0,
        results
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})

// Simulated SMS sending function - replace with actual SMS service
async function sendSMS(phoneNumber: string, message: string) {
  try {
    // Example Twilio integration (replace with your actual service)
    // const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID')
    // const authToken = Deno.env.get('TWILIO_AUTH_TOKEN')
    // const fromNumber = Deno.env.get('TWILIO_PHONE_NUMBER')
    
    // For demo purposes, we'll simulate success
    console.log(`Sending SMS to ${phoneNumber}: ${message}`)
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 100))
    
    return {
      success: true,
      messageId: `msg_${Date.now()}`
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}