/*
  # Create SMS logs table

  1. New Tables
    - `sms_logs`
      - `id` (uuid, primary key)
      - `target_phone` (text)
      - `message` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `sms_logs` table
    - Add policy for authenticated users to manage SMS logs
*/

CREATE TABLE IF NOT EXISTS sms_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  target_phone text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sms_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage SMS logs"
  ON sms_logs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);