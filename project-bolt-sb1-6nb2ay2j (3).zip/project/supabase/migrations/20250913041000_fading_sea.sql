/*
  # Add parent information to invoices table

  1. New Columns
    - `parent_name` (text) - Father's name for the invoice
    - `parent_contact` (varchar) - Father's contact information
  
  2. Changes
    - Add parent_name column to store father's name
    - Add parent_contact column to store father's contact
    - These fields are optional and can be null
  
  3. Notes
    - Uses IF NOT EXISTS to prevent errors on re-run
    - Safe migration that won't affect existing data
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'invoices' AND column_name = 'parent_name'
  ) THEN
    ALTER TABLE invoices ADD COLUMN parent_name text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'invoices' AND column_name = 'parent_contact'
  ) THEN
    ALTER TABLE invoices ADD COLUMN parent_contact varchar;
  END IF;
END $$;