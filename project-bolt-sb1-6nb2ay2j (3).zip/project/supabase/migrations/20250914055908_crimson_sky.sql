/*
  # Create payments table for payment confirmations

  1. New Tables
    - `payments`
      - `id` (uuid, primary key)
      - `invoice_id` (uuid, foreign key to invoices)
      - `reference_number` (text) - payment reference from user
      - `created_at` (timestamp)
      - `status` (text) - pending, verified, rejected

  2. Security
    - Enable RLS on `payments` table
    - Add policy for public insert (payment confirmations)
*/

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES invoices(id) ON DELETE CASCADE,
  reference_number text NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit payment confirmations"
  ON payments
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (true);