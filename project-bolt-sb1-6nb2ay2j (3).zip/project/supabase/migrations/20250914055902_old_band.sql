/*
  # Add pay_link column to invoices table

  1. New Column
    - `pay_link` (text, unique) - unique payment link identifier for each invoice
  
  2. Security
    - No RLS changes needed as invoices table already has RLS enabled
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'invoices' AND column_name = 'pay_link'
  ) THEN
    ALTER TABLE invoices ADD COLUMN pay_link text UNIQUE;
  END IF;
END $$;