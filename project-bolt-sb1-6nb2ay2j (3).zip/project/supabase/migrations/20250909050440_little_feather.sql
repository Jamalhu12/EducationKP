/*
  # Create student-parent relationship table and fee management

  1. New Tables
    - `student_parents`
      - `id` (uuid, primary key)
      - `student_id` (uuid, foreign key to students)
      - `parent_id` (uuid, foreign key to parents)
      - `created_at` (timestamp)
    - `invoices` (already exists, but adding RLS)

  2. Security
    - Enable RLS on `student_parents` table
    - Add policies for authenticated users
    - Enable RLS on existing tables if not already enabled

  3. Relationships
    - Many-to-many relationship between students and parents
    - One-to-many relationship between students and invoices
*/

-- Create student_parents junction table
CREATE TABLE IF NOT EXISTS student_parents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, parent_id)
);

-- Enable RLS on student_parents
ALTER TABLE student_parents ENABLE ROW LEVEL SECURITY;

-- Create policy for student_parents
CREATE POLICY "Users can manage student-parent relationships"
  ON student_parents
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Enable RLS on existing tables if not already enabled
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE parents ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- Create policies for students
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'students' AND policyname = 'Users can manage students'
  ) THEN
    CREATE POLICY "Users can manage students"
      ON students
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for parents
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'parents' AND policyname = 'Users can manage parents'
  ) THEN
    CREATE POLICY "Users can manage parents"
      ON parents
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for invoices
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'invoices' AND policyname = 'Users can manage invoices'
  ) THEN
    CREATE POLICY "Users can manage invoices"
      ON invoices
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;